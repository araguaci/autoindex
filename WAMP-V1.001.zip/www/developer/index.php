<?php
echo "<h1>D:\app_aragua\_developer</h1>";
header("Location: http://localhost/app_aragua/_developer/")
?>