<?php
echo "<h1>H:\_docs</h1>";
header("Location: http://docs/")
?>