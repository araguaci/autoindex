<?php
echo "<h1>\C:\Users\aragu\Downloads</h1>";
header("Location: http://localhost/downloads/")
?>