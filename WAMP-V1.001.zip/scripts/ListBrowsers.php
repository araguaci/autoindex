<?php

$browser = array (
  'name' => 
  array (
    0 => 'Internet Explorer',
    1 => 'Microsoft Edge',
  ),
  'path' => 
  array (
    0 => 'C:/Program Files/Internet Explorer/iexplore.exe',
    1 => 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  ),
);

?>
